# AJ Beauty Studio

Beauty • Events • Moments

MVP foundation: Next.js + TypeScript + Tailwind CSS + Supabase.

Supabase project ref: biwarhlenacommoeftlc

## MVP
- Homepage
- Portfolio categories
- Services & pricing
- Booking form
- Choose Your Look
- Protected admin dashboard foundation
- Supabase Auth / Storage / RLS

## Environment
Copy `.env.example` to `.env.local` and add the Supabase URL and publishable key.

## Next phase
Full admin CRUD, calendar, events management, WhatsApp notifications, deposits/payments and advanced booking conflict rules.
